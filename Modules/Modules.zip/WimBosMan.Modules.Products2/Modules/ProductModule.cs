﻿using System.Collections.Generic;
using CeyenneNxt.Modules;
using CeyenneNxt.Modules.Products.Shared;
using CeyenneNxt.Modules.Products.Shared.Dtos;

namespace WimBosman.Modules.Products.Modules
{
    public class WimBosmanProductModule : ProductModule, IProductModule
    {
      public override List<ProductDto> GetProducts()
      {
        var products = base.GetProducts();
        products.Add(new ProductDto() {ID = 3,Name = "Product 3"});
        return products;
      }

      public WimBosmanProductModule(IProductRepository productRepository) : base(productRepository)
      {
      }
    }
}
