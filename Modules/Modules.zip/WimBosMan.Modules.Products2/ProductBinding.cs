﻿using CeyenneNxt.Modules.Products.Shared;
using Ninject.Modules;
using WimBosman.Modules.Products.Controllers;
using WimBosman.Modules.Products.Modules;

namespace WimBosman.Modules.Products
{
  public class ProductBinding : NinjectModule
  {
    public override void Load()
    {
      Rebind<IProductModule>().To<WimBosmanProductModule>();
    }
  }
}
