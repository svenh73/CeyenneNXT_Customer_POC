﻿xcopy /E /Y "$(TargetPath)" "$(SolutionDir)Web\CeyenneNxt.Web.WebUI\bin\"
xcopy /E /Y "$(ProjectDir)Views" "$(SolutionDir)Web\CeyenneNxt.Web.WebUI\Views\"
xcopy /E /Y "$(ProjectDir)Content" "$(SolutionDir)Web\CeyenneNxt.Web.WebUI\Content\"
xcopy /E /Y "$(ProjectDir)Scripts" "$(SolutionDir)Web\CeyenneNxt.Web.WebUI\Scripts\"

