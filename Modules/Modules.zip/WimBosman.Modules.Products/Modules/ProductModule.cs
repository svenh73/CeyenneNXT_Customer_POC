﻿using System.Collections.Generic;
using CeyenneNxt.Products.Module;
using CeyenneNxt.Products.Shared.Dtos;
using CeyenneNxt.Products.Shared.Interfaces;

namespace WimBosman.Products.Module.Modules
{
    public class WimBosmanProductModule : ProductModule, IProductModule
    {
      public override List<ProductDto> GetProducts()
      {
        var products = base.GetProducts();
        products.Add(new ProductDto() {ID = 3,Name = "Product 3"});
        return products;
      }

      public WimBosmanProductModule(IProductRepository productRepository) : base(productRepository)
      {
      }
    }
}
